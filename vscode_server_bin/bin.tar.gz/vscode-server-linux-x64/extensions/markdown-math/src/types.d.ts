/// <reference path='../../../src/vs/vscode.d.ts'/>
